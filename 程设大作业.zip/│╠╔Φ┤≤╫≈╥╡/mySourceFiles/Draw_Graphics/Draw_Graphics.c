#include "graphics.h"
#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"
#include "random.h"
#include "strlib.h"
#include "conio.h"
#include "imgui.h"

#include "struct.h"
#include "In_Graphics.h"
#include "display_Draw.h"
#include "Menu_Select.h"
#include "Mouse_Event.h"
#include "Text_Edit.h"

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include <string.h>
#include <math.h>

extern double window_width,window_height,back_n1 ,back_n2 ,back_n3 ,back_h1 ,back_h2 ,back_h3 ,back_w1 ,back_w2 ,back_w3;
extern int select_file;
#define Pi 3.1415926
/*ֱ�߸�������*/ 
void forward_line(double length, double angle, char * color) 
{
	SetPenColor(color);
	double rad = (angle/180)*Pi;
	DrawLine(length*cos(rad), length*sin(rad));
	SetPenColor("BLUE");
}
/*���߸�������*/ 
void forward_dotted_line(double length, double angle, char * color)
{
	double l = 0;
	int count = 0;
	/*0.1�̶����뽻�滭���γ�����*/ 
	while(length-l>0.1)
	{
		if(count%2==0)
		forward_line(0.1, angle, color);
		else
		forward_line(0.1, angle, "WHITE");
		count++;
		l += 0.1;
	}
	if(count%2==0)
	forward_line(length-l, angle, color);
	else
	forward_line(length-l, angle, "WHITE");
}
/*���ƾ���*/ 
void Draw_Rec(double x, double y, double width, double height, double angle, char * text, int line_type,
int pensize, char * graphic_color, char * text_color, char * fill_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	double rad = (angle/180)*Pi;  /*�ѽǶ�ת���ɻ���*/
	double rad0 = atan(height/width);
	double l = sqrt(pow(height,2)+pow(width,2))/2;  /*��������������һ���������ߵĳ���*/ 
	
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		MovePen(x-l*cos(rad+rad0), y-l*sin(rad+rad0));
		SetPenColor(fill_color);
		StartFilledRegion(1);
		DrawLine(height*cos(rad+Pi/2), height*sin(rad+Pi/2));
	    DrawLine(width*cos(rad), width*sin(rad));
	    DrawLine(-height*cos(rad+Pi/2), -height*sin(rad+Pi/2));
	    DrawLine(-width*cos(rad), -width*sin(rad));
	    EndFilledRegion();
	}

	/*�Ȼ�ͼ�Σ������ʹ���*/
	if(line_type==1||line_type==2)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color); 
	    MovePen(x-l*cos(rad+rad0), y-l*sin(rad+rad0));
	    DrawLine(height*cos(rad+Pi/2), height*sin(rad+Pi/2));
	    DrawLine(width*cos(rad), width*sin(rad));
	    DrawLine(-height*cos(rad+Pi/2), -height*sin(rad+Pi/2));
	    DrawLine(-width*cos(rad), -width*sin(rad));
	    if(line_type==2)
	    Draw_Rec(x, y, width-0.1, height-0.1, angle, "", 1, pensize, graphic_color, text_color, fill_color);
	}
	else if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color); 
		MovePen(x-l*cos(rad+rad0), y-l*sin(rad+rad0));
		forward_dotted_line(height, angle+90, graphic_color); 
		forward_dotted_line(width, angle, graphic_color);
		forward_dotted_line(height, angle-90, graphic_color);
		forward_dotted_line(width, angle-180, graphic_color);
		if(line_type==4)
	    Draw_Rec(x, y, width-0.1, height-0.1, angle, "", 3, pensize, graphic_color, text_color, fill_color);
	}
	
	/*�ٴ�ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);

    SetPenSize(1);
	SetPenColor("BLUE");
}
/*����Բ�Ǿ���*/ 
void Draw_RoundedRec(double x, double y, double width, double height, double angle, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	double rad = (angle/180)*Pi;  /*�ѽǶ�ת���ɻ���*/
	double rad0 = atan(height/width);
	double l = sqrt(pow(height,2)+pow(width,2))/2;  /*��������������һ���������ߵĳ���*/ 
	
	width -= 0.2;
	height -= 0.2;
	
	/*���*/
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x-l*cos(rad+rad0)+0.1*cos(rad), y-l*sin(rad+rad0)+0.1*sin(rad));
		StartFilledRegion(1);
		DrawLine((height+0.2)*cos(rad+Pi/2), (height+0.2)*sin(rad+Pi/2));
		DrawLine(width*cos(rad), width*sin(rad));
		DrawLine(-(height+0.2)*cos(rad+Pi/2), -(height+0.2)*sin(rad+Pi/2));
		DrawLine(-width*cos(rad), -width*sin(rad));
		EndFilledRegion();
		
		DrawArc(0.1, angle+270, -90);
		StartFilledRegion(1);
		DrawLine(height*cos(rad+Pi/2), height*sin(rad+Pi/2));
		DrawLine((width+0.2)*cos(rad), (width+0.2)*sin(rad));
		DrawLine(-height*cos(rad+Pi/2), -height*sin(rad+Pi/2));
		DrawLine(-(width+0.2)*cos(rad), -(width+0.2)*sin(rad));
		EndFilledRegion();
		
		MovePen(x-l*cos(rad+rad0)+0.1*cos(rad), y-l*sin(rad+rad0)+0.1*sin(rad));
		StartFilledRegion(1);
		DrawArc(0.1, angle+270, 360);
		EndFilledRegion();
		
		DrawArc(0.1, angle+270, -90);
		DrawLine(height*cos(rad+Pi/2), height*sin(rad+Pi/2));
		StartFilledRegion(1);
		DrawArc(0.1, angle+180, 360);
		EndFilledRegion();
		
		DrawArc(0.1, angle+180, -90);
	    DrawLine(width*cos(rad), width*sin(rad));
	    StartFilledRegion(1);
	    DrawArc(0.1, angle+90, 360);
	    EndFilledRegion();
	    
	    DrawArc(0.1, angle+90, -90);
	    DrawLine(-height*cos(rad+Pi/2), -height*sin(rad+Pi/2));
	    StartFilledRegion(1);
	    DrawArc(0.1, angle, 360);
	    EndFilledRegion();
	    SetPenColor("BLUE");
	} 
	/*�Ȼ�ͼ�Σ������ʹ���*//*�Ȼ�ͼ��*/
	if(line_type==1||line_type==2)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color); 
	    MovePen(x-l*cos(rad+rad0)+0.1*cos(rad), y-l*sin(rad+rad0)+0.1*sin(rad));
	    DrawArc(0.1, angle+270, -90);
	    DrawLine(height*cos(rad+Pi/2), height*sin(rad+Pi/2));
	    DrawArc(0.1, angle+180, -90);
	    DrawLine(width*cos(rad), width*sin(rad));
		DrawArc(0.1, angle+90, -90);
	    DrawLine(-height*cos(rad+Pi/2), -height*sin(rad+Pi/2));
	    DrawArc(0.1, angle, -90);
	    DrawLine(-width*cos(rad), -width*sin(rad));
	    if(line_type==2)
	    Draw_RoundedRec(x, y, width+0.1, height+0.1, angle, "", 1, pensize, graphic_color, text_color, fill_color);
	}
	else if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
		MovePen(x-l*cos(rad+rad0)+0.1*cos(rad), y-l*sin(rad+rad0)+0.1*sin(rad));
	    DrawArc(0.1, angle+270, -90);
		forward_dotted_line(height, angle+90, graphic_color); 
		SetPenColor(graphic_color);
		DrawArc(0.1, angle+180, -90);
		forward_dotted_line(width, angle, graphic_color);
		SetPenColor(graphic_color);
		DrawArc(0.1, angle+90, -90);
		forward_dotted_line(height, angle-90, graphic_color);
		SetPenColor(graphic_color);
		DrawArc(0.1, angle, -90);
		forward_dotted_line(width, angle-180, graphic_color);
		if(line_type==4)
	    Draw_RoundedRec(x, y, width+0.1, height+0.1, angle, "", 3, pensize, graphic_color, text_color, fill_color);
	}
	
	/*�ٴ�ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}
/*����Բ��*/ 
void Draw_Arc(double x, double y, double r, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���*/ 
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x+r, y);
		StartFilledRegion(1);
		DrawArc(r, 0, 360);
	    EndFilledRegion();
	    SetPenColor("BLUE");
	}
	/*�Ȼ�ͼ�Σ������ʹ���*/
	if(line_type==1||line_type==2)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x+r, y);
	    DrawArc(r, 0, 360);
	    if(line_type==2)
	    Draw_Arc(x, y, r-0.05, "", 1, pensize, graphic_color, text_color, fill_color);
	}
	else if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x+r, y);
		double d_angle = (0.1/r)/Pi*180;
		double sum_angle = 0;
		int count = 0;
		while(sum_angle<360)
		{
			if(count%2==0)
			{
				SetPenColor(graphic_color);
				DrawArc(r, sum_angle, d_angle);
			}
			else
			{
				SetPenColor("WHITE");
				DrawArc(r, sum_angle, d_angle);
			}
			count++;
			sum_angle += d_angle;
		}
		if(line_type==4)
	    Draw_Arc(x, y, r-0.05, "", 3, pensize, graphic_color, text_color, fill_color);
	}
	/*�ٴ�ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}
/*������Բ*/ 
void Draw_EllipticalArc(double x, double y, double rx, double ry, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���*/ 
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x+rx, y);
		StartFilledRegion(1);
		DrawEllipticalArc(rx, ry, 0, 360);
	    EndFilledRegion();
	    SetPenColor("BLUE");
	}
	/*�Ȼ�ͼ�Σ������ʹ���*/
	if(line_type==1||line_type==2)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x+rx, y);
	    DrawEllipticalArc(rx, ry, 0, 360);
	    if(line_type==2)
	    Draw_EllipticalArc(x, y, rx-0.05, ry-0.05, "", 1, pensize, graphic_color, text_color, fill_color);
	}
	else if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x+rx, y);
	    double d_angle = (0.1/rx)/Pi*180;
		double sum_angle = 0;
		int count = 0;
		while(sum_angle<360)
		{
			if(count%2==0)
			{
				SetPenColor(graphic_color);
				DrawEllipticalArc(rx, ry, sum_angle, d_angle);
			}
			else
			{
				SetPenColor("WHITE");
				DrawEllipticalArc(rx, ry, sum_angle, d_angle);
			}
			count++;
			sum_angle += d_angle;
		}
		if(line_type==4)
	    Draw_EllipticalArc(x, y, rx-0.05, ry-0.05, "", 3, pensize, graphic_color, text_color, fill_color);
	} 
	/*�ٴ�ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}
/*��������*/ 
void Draw_Diamond(double x, double y, double length, double angle, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	double rad = (angle/180)*Pi;
	double l = length*sin(2*Pi/3);  /*l�������������Զ�������ߵĳ���*/ 
	/*���*/ 
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x-l*cos(rad), y-l*sin(rad));
		StartFilledRegion(1);
		DrawLine(length*cos(rad+Pi/6), length*sin(rad+Pi/6));
        DrawLine(length*cos(rad-Pi/6), length*sin(rad-Pi/6));
	    DrawLine(-length*cos(rad+Pi/6), -length*sin(rad+Pi/6));
	    DrawLine(-length*cos(rad-Pi/6), -length*sin(rad-Pi/6));
	    EndFilledRegion();
	    SetPenColor("BLUE");
	}
	/*�Ȼ�ͼ�Σ������ʹ���*/
	if(line_type==1||line_type==2)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x-l*cos(rad), y-l*sin(rad));
	    DrawLine(length*cos(rad+Pi/6), length*sin(rad+Pi/6));
	    DrawLine(length*cos(rad-Pi/6), length*sin(rad-Pi/6));
	    DrawLine(-length*cos(rad+Pi/6), -length*sin(rad+Pi/6));
	    DrawLine(-length*cos(rad-Pi/6), -length*sin(rad-Pi/6));
	    if(line_type==2)
	    Draw_Diamond(x, y, length-0.1, angle, "", 1, pensize, graphic_color, text_color, fill_color);
	}
	else if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
	    SetPenColor(graphic_color);
	    MovePen(x-l*cos(rad), y-l*sin(rad));
	    forward_dotted_line(length, angle+30, graphic_color);
	    forward_dotted_line(length, angle-30, graphic_color);
	    forward_dotted_line(length, angle-150, graphic_color);
	    forward_dotted_line(length, angle-210, graphic_color);
	    if(line_type==4)
	    Draw_Diamond(x, y, length-0.1, angle, "", 3, pensize, graphic_color, text_color, fill_color);
	}
	/*�ٴ�ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}

/*������������*/ 
void Draw_Triangle(double x, double y, double l, double angle, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	double rad=angle/180*Pi;/*�Ƕȱ�Ϊ����*/ 
	double c=sqrt(3);
	/*���*/
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x-c/3*l*sin(rad),y+c/3*l*cos(rad));
		StartFilledRegion(1);
		DrawLine(l*cos(Pi/3-rad),-l*sin(Pi/3-rad));
		DrawLine(-l*cos(rad),-l*sin(rad));
		DrawLine(l*cos(Pi/3+rad),l*sin(Pi/3+rad));
		EndFilledRegion();
	}
	/*�Ȼ�ͼ��*/
	if(line_type==1||line_type==2)
	{
		SetPenColor(graphic_color);
		SetPenSize(pensize);
		MovePen(x-c/3*l*sin(rad),y+c/3*l*cos(rad));
		DrawLine(l*cos(Pi/3-rad),-l*sin(Pi/3-rad));
		DrawLine(-l*cos(rad),-l*sin(rad));
		DrawLine(l*cos(Pi/3+rad),l*sin(Pi/3+rad));
		if(line_type==2)
		Draw_Triangle(x,y,l-0.2,angle,text,1,pensize,graphic_color,text_color,fill_color);
	} 
	if(line_type==3||line_type==4)
	{
		SetPenSize(pensize);
		MovePen(x-c/3*l*sin(rad),y+c/3*l*cos(rad));
		forward_dotted_line(l,angle-60,graphic_color);
		forward_dotted_line(l,angle+180,graphic_color);
		forward_dotted_line(l,angle+60,graphic_color);
		if(line_type==4)
		Draw_Triangle(x,y,l-0.2,angle,text,3,pensize,graphic_color,text_color,fill_color);
	} 
	/*�ٴ�ӡ�ı�*/ 
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}
/*����ƽ���ı���*/
void Draw_Parallelogram(double x, double y, double l, double width, double height, double angle, char * text, int line_type, int pensize, char * graphic_color,
char * text_color, char * fill_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	double rad=angle/180*Pi;/*�Ƕȱ�Ϊ����*/ 
	double rad0=asin(height/l);
	double l1=sqrt(pow(l,2)+pow(width,2)-2*l*width*cos(rad0));
	double rad00=asin(l*sin(rad0)/l1);
	/*���*/
	if(line_type==1||line_type==3||strcmp(fill_color, "WHITE")==0)
	{
		SetPenColor(fill_color);
		MovePen(x-l1/2*cos(rad00-rad),y+l1/2*sin(rad00-rad));
		StartFilledRegion(1);
		DrawLine(width*cos(rad),width*sin(rad));
		DrawLine(-l*cos(rad0+rad),-l*sin(rad0+rad));
		DrawLine(-width*cos(rad),-width*sin(rad));
		DrawLine(l*cos(rad0+rad),l*sin(rad0+rad));
		EndFilledRegion();
	} 
	/*�Ȼ�ͼ��*/
	if(line_type==1||line_type==2)
	{
		SetPenColor(graphic_color);
		SetPenSize(pensize);
		MovePen(x-l1/2*cos(rad00-rad),y+l1/2*sin(rad00-rad));
		DrawLine(width*cos(rad),width*sin(rad));
		DrawLine(-l*cos(rad0+rad),-l*sin(rad0+rad));
		DrawLine(-width*cos(rad),-width*sin(rad));
		DrawLine(l*cos(rad0+rad),l*sin(rad0+rad));
		if(line_type==2)
		Draw_Parallelogram(x,y,(height-0.15)/sin(rad0),width-0.2,height-0.15,angle,text,1,pensize,graphic_color,text_color,fill_color);
	}
	if(line_type==3||line_type==4)
	{
		SetPenColor(graphic_color);
		SetPenSize(pensize);
		MovePen(x-l1/2*cos(rad00-rad),y+l1/2*sin(rad00-rad));
		forward_dotted_line(width,angle,graphic_color);
		forward_dotted_line(l,(rad0+rad+Pi)*180/Pi,graphic_color);
		forward_dotted_line(width,angle+180,graphic_color);
		forward_dotted_line(l,(rad0+rad)*180/Pi,graphic_color);
		if(line_type==4)
		Draw_Parallelogram(x,y,(height-0.15)/sin(rad0),width-0.2,height-0.15,angle,text,3,pensize,graphic_color,text_color,fill_color);
	}
	/*�ٴ�ӡ�ı�*/ 
	SetPenColor(text_color);
	drawLabel(x-strlen(text)/2*0.08, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}

/*����ֱ��*/ 
void Draw_Line(double x, double y, double length, double angle, int line_type, int pensize, char * graphic_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	/*��ͼ��*/
	double rad = (angle/180)*Pi;
	
	SetPenSize(pensize);
	SetPenColor(graphic_color);
	MovePen(x-length/2*cos(rad), y-length/2*sin(rad));
	if(line_type==1)
	DrawLine(length*cos(rad), length*sin(rad));
	else if(line_type==2)
	{
		Draw_Line(x+0.02*cos(rad+Pi/2), y+0.02*sin(rad+Pi/2), length, angle, 1, pensize, graphic_color);
		Draw_Line(x-0.02*cos(rad+Pi/2), y-0.02*sin(rad+Pi/2), length, angle, 1, pensize, graphic_color);
	}
	else if(line_type==3)
	forward_dotted_line(length, angle, graphic_color);
	else if(line_type==4)
	{
		MovePen(x-length/2*cos(rad)+0.02*cos(rad+Pi/2), y-length/2*sin(rad)+0.02*sin(rad+Pi/2));
		forward_dotted_line(length, angle, graphic_color);
		MovePen(x-length/2*cos(rad)-0.02*cos(rad+Pi/2), y-length/2*sin(rad)-0.02*sin(rad+Pi/2));
		forward_dotted_line(length, angle, graphic_color);
	}
	
	SetPenSize(1);
	SetPenColor("BLUE");
}
/*���Ƽ�ͷֱ��*/ 
void Draw_Arrow(double x, double y, double length, double angle, int line_type, int pensize, char * graphic_color)
{
	/*���Ƕȷǳ��ӽ�90��������ʱ������ת����90��������*/ 
	if(fabs((int)angle%90)<5)
	angle = (int)angle/90*90;
	else if(fabs((int)angle%90)>85)
	{
		if(angle>0)
		angle = (int)(angle+5)/90*90;
		else
		angle = (int)(angle-5)/90*90;
	}
	
	/*��ͼ��*/
	double rad = (angle/180)*Pi;
	
	SetPenSize(pensize);
	SetPenColor(graphic_color);
	MovePen(x-length/2*cos(rad), y-length/2*sin(rad));
	if(line_type==1)
	DrawLine(length*cos(rad), length*sin(rad));
	else if(line_type==2)
	{
		Draw_Line(x+0.02*cos(rad+Pi/2), y+0.02*sin(rad+Pi/2), length, angle, 1, pensize, graphic_color);
		Draw_Line(x-0.02*cos(rad+Pi/2), y-0.02*sin(rad+Pi/2), length, angle, 1, pensize, graphic_color);
	}
	else if(line_type==3)
	forward_dotted_line(length, angle, graphic_color);
	else if(line_type==4)
	{
		MovePen(x-length/2*cos(rad)+0.02*cos(rad+Pi/2), y-length/2*sin(rad)+0.02*sin(rad+Pi/2));
		forward_dotted_line(length, angle, graphic_color);
		MovePen(x-length/2*cos(rad)-0.02*cos(rad+Pi/2), y-length/2*sin(rad)-0.02*sin(rad+Pi/2));
		forward_dotted_line(length, angle, graphic_color);
	}
	
	MovePen(x+length/2*cos(rad), y+length/2*sin(rad));
	DrawLine(-0.1*cos(rad-Pi/4), -0.1*sin(rad-Pi/4));
	DrawLine(0.1*cos(rad-Pi/4), 0.1*sin(rad-Pi/4));
	DrawLine(-0.1*cos(rad+Pi/4), -0.1*sin(rad+Pi/4));
	
	SetPenSize(1);
	SetPenColor("BLUE");
}

/*�����ı�*/ 
void Draw_Text(double x, double y, char * text_color, char * text)
{
	/*��ӡ�ı�*/
	SetPenColor(text_color);
	drawLabel(x, y, text);
	
	SetPenSize(1);
	SetPenColor("BLUE");
}


/*
void DrawFilledRegion(){
	SetPenColor("WHITE");
	MovePen(0,0);
	StartFilledRegion(1);
	DrawLine(window_width,0);
	DrawLine(0,0.6);
	DrawLine(-window_width,0);
	DrawLine(0,-0.6);
	EndFilledRegion();
	MovePen(0,window_height);
	StartFilledRegion(1);
	DrawLine(window_width,0);
	DrawLine(0,-0.3);
	DrawLine(-window_width,0);
	DrawLine(0,0.3);
	EndFilledRegion();
	SetPenColor("BLUE");
}

void Draw_BackGround(){
	double n,h,w;
	if(select_file==0)
	;
	else if(select_file==1)
	{
		n=back_n1;
		h=back_h1;
		w=back_w1;
	}
	else if(select_file==2)
	{
		n=back_n2;
		h=back_h2;
		w=back_w2;
	}
	else if(select_file==3)
	{
		n=back_n3;
		h=back_h3;
		w=back_w3;
	}
	double dh=(window_height-0.9)/n;
	double dw=(window_width)/n;
	SetPenSize(0.1);
	SetPenColor("light gray");
	while(h<window_height-0.3){
		MovePen(0,h);
		if(h>0.6)
			DrawLine(window_width,0);
		h+=dh;
	}
	while(w<window_width){
		MovePen(w,0.6);
		DrawLine(0,window_height-0.9);
		w+=dw;
	}
}
*/

