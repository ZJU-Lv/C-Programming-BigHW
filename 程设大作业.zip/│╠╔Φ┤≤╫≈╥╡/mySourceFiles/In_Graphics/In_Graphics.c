#include "graphics.h"
#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"
#include "random.h"
#include "strlib.h"
#include "conio.h"
#include "imgui.h"

#include "struct.h"
#include "Draw_Graphics.h"
#include "display_Draw.h"
#include "Menu_Select.h"
#include "Mouse_Event.h"
#include "Text_Edit.h"

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include <string.h>
#include <math.h>

#define Pi 3.1415926

/*��ṹ*/ 
struct point{
	double x;
	double y;
};
/*�ж����λ���Ƿ��ھ����ڲ�*/ 
bool In_Rec(double x, double y, double rec_x, double rec_y, double width, double height, double angle)
{
	double rad = (angle/180)*Pi;/*�Ƕ�ת����*/ 
	double rad_1 = atan((y-rec_y)/(x-rec_x));/*�ڲ�������*/ 
	if(x<rec_x)
	rad_1 += Pi;
	double l = sqrt(pow(y-rec_y,2)+pow(x-rec_x,2));
	double rad_2 = rad_1-rad;
	if(fabs(l*cos(rad_2))<width/2&&fabs(l*sin(rad_2))<height/2)
	return TRUE;
	else
	return FALSE;
}
/*�ж����λ���Ƿ���Բ���ڲ�*/ 
bool In_Arc(double x, double y, double arc_x, double arc_y, double r)
{
	double l = sqrt(pow(y-arc_y,2)+pow(x-arc_x,2));
	if(l<r)
	return TRUE;
	else
	return FALSE;
}
/*�ж����λ���Ƿ�����Բ�ڲ�*/ 
bool In_EllipticalArc(double x, double y, double arc_x, double arc_y, double rx, double ry)
{
	double rad = atan((y-arc_y)/(x-arc_x));/*�ڲ�������*/ 
	if(x<arc_x)/*������Ƕ�ת���������*/ 
	rad += Pi;
	if(rad>3*Pi/2)
	rad = 2*Pi-rad;
	else if(rad>Pi)
	rad -= Pi;
	else if(rad>Pi/2)
	rad = Pi-rad;
	
	double l = sqrt(pow(y-arc_y,2)+pow(x-arc_x,2));
	double l_max = sqrt((double)1/(pow(cos(rad)/rx,2)+pow(sin(rad)/ry,2)));
	if(l<l_max)
	return TRUE;
	else
	return FALSE;
}
/*�ж����λ���Ƿ��������ڲ�*/ 
bool In_Diamond(double x, double y, double dia_x, double dia_y, double length, double angle)
{
	double rad = (angle/180)*Pi;/*�Ƕ�ת����*/ 
	double rad_1 = atan((y-dia_y)/(x-dia_x));/*�ڲ�������*/ 
	if(x<dia_x)
	rad_1 += Pi;
	double l = sqrt(pow(y-dia_y,2)+pow(x-dia_x,2));
	double rad_2 = rad_1-rad;
	while(rad_2<0||rad_2>2*Pi)
	{
		if(rad_2<0)
		rad_2 += 2*Pi;
		else
		rad_2 -= 2*Pi;
	}
	if(rad_2>3*Pi/2)
	rad_2 = 2*Pi-rad_2;
	else if(rad_2>Pi)
	rad_2 -= Pi;
	else if(rad_2>Pi/2)
	rad_2 = Pi-rad_2;
	
	double rad_3 = Pi-rad_2-Pi/6;
	double L = length*sin(Pi/3);  /*L��������������һ�������ߵĳ���*/
	double l_max = L/sin(rad_3)*sin(Pi/6);
	if(l<l_max)
	return TRUE;
	else
	return FALSE; 
}

/*�ж����λ���Ƿ����������ڲ�*/ 
bool In_Triangle(double tx, double ty, double x, double y, double length, double angle)
{
	struct point a,b,c;
	double rad=angle/180*Pi;
	double l=sqrt(3)/3.0*length;
	a.x=x-l*sin(rad);a.y=y+l*cos(rad);
	b.x=x-l*cos(rad+Pi/6);b.y=y-l*sin(rad+Pi/6);
	c.x=x+l*cos(Pi/6-rad);c.y=y-l*sin(Pi/6-rad);
	if(fabs((a.x-tx)*(b.y-ty)-(b.x-tx)*(a.y-ty))/2.0
	  +fabs((a.x-tx)*(c.y-ty)-(c.x-tx)*(a.y-ty))/2.0
	  +fabs((b.x-tx)*(c.y-ty)-(c.x-tx)*(b.y-ty))/2.0-l*3.0/4.0*length<0.001)
		return TRUE;
	else
		return FALSE;
}
/*�ж����λ���Ƿ���ƽ���ı����ڲ�*/ 
bool In_Parallelogram(double x, double y, double px, double py, double width, double height, double l, double angle)
{
	double rad=angle/180*Pi;
	double rad_1=asin(height/l);
	double l1=sqrt(pow(l,2)+pow(width,2)-2*l*width*cos(rad_1))/2;
	double l2=sqrt(pow(l,2)+pow(width,2)-2*l*width*cos(Pi-rad_1))/2;
	double rad_2=asin(height/l1/2);
	double rad_3=asin(height/2/l2);
	struct point a,b,c,d;
	a.x=px-l1*sin(Pi/2-rad_2+rad);a.y=py+l1*cos(Pi/2-rad_2+rad);
	b.x=px-l2*cos(rad+rad_3);b.y=py-l2*sin(rad+rad_3);
	c.x=px*2-a.x;c.y=py*2-a.y;
	d.x=px*2-b.x;d.y=py*2-b.y;
	if(fabs((a.x-x)*(b.y-y)-(b.x-x)*(a.y-y))/2.0
	  +fabs((a.x-x)*(d.y-y)-(d.x-x)*(a.y-y))/2.0
	  +fabs((b.x-x)*(c.y-y)-(c.x-x)*(b.y-y))/2.0
	  +fabs((c.x-x)*(d.y-y)-(d.x-x)*(c.y-y))/2.0-width*height<0.001)
	  	return TRUE;
	else
		return FALSE; 
}
